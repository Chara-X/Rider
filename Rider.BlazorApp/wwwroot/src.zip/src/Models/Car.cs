﻿namespace Rider.BlazorApp.wwwroot.src.Models
{
    public class Car
    {
    }
}
