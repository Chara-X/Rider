﻿namespace Rider.BlazorApp.wwwroot.src
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("Hello, World");
        }
    }
}
