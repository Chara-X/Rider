﻿namespace Rider.BlazorApp.wwwroot.src.Services
{
    public class UserService
    {
    }
}
